import styled from 'styled-components';

export const NameInputContainer = styled.div`
    display: flex;
    height: 70px;
    align-items: center;
    justify-content: space-between;
`;