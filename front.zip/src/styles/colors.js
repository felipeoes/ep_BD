export const colors = {
    primary: '#070F65',
    secondary: '#0D177A',
    terciary: '#142297',
    mainBlue: '#2940D3',
    blueTransparent: '#D4DBFC',
    purpleTransparent: '#A9B8FA',
    transparentText: '#9998A1',
    textTitle: '#283252',
    background: '#363740',
    transparentButton: 'rgba(45, 40, 91, 0.64)',
    transparentModal: 'rgba(18, 16, 37, 0.59)',
};