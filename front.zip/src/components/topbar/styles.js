import styled from 'styled-components';

export const UserIcon = styled.img`
    border-radius: 50%;
    width: 42px;
    height: 42px;
`;